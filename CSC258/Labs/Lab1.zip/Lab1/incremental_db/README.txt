This folder contains data for incremental compilation.

The compiled_partitions sub-folder contains previous compilation results for each partition.
As long as this folder is preserved, incremental compilation results from earlier compiles
can be re-used.  To perform a clean compilation from source files for all partitions, both
the db and incremental_db folder should be removed.

The imported_partitions sub-folder contains the last imported QXP for each imported partition.
As long as this folder is preserved, imported partitions will be automatically re-imported
when the db or incremental_db/compiled_partitions folders are removed.

