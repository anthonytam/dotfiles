<?php
    // Library for php password functions which are avaliable in php 5.5 (The server is running 5.3)
    // The library was exported by the below user on github
    // Source: https://github.com/ircmaxell/password_compat
    require "includes/password.php";
    require_once "includes/config.php"; //Config Variables and Global Functions
    require_once "model/user.php";
    require_once "model/ClassManager.php";
    require_once "model/ClassInfo.php";

    session_save_path("sess");

    // TODO: Prevent session theft
    session_start(); 

    ini_set('display_errors', 'On');

    if(!isset($_SESSION['messages'])) {
        $_SESSION['messages'] = array();
    }

    if(!isset($_SESSION['state'])) {
        $_SESSION['state'] = "login";
    }

    //Handle link presses
    if(isset($_REQUEST['request'])) {
        $serverPage = explode("?", $_SERVER['REQUEST_URI'], 2); //Get rid of the get parameters from the URL
        if(isset($_SESSION['user']) && $_SESSION['user']->isValidLogin) {
            switch($_REQUEST['request']) {
                case "class":
                    $_SESSION['state'] = $_SESSION['user']->isInstructor ? "createclass" : "joinclass";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $serverPage[0]);
                    die;
                    break;
                case "logout":
                    session_destroy();
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $serverPage[0]);
                    die;
                    break;
                case "profile":
                    $_SESSION['state'] = "profile";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $serverPage[0]);
                    die;
                    break;
            }
        } else {
            if($_REQUEST['request'] == "register") {
                $_SESSION['state'] = "register";
                header("Location: http://" . $_SERVER['HTTP_HOST'] . $serverPage[0]);
                die;
            } elseif ($_REQUEST['request'] == "logout") {
                session_destroy();
                header("Location: http://" . $_SERVER['HTTP_HOST'] . $serverPage[0]);
                die;
            } else {
                $_SESSION['messages'][] = "You are not logged in";
                header("Location: http://" . $_SERVER['HTTP_HOST'] . $serverPage[0]);
                die;
            }
        }
    }
    if(isset($_REQUEST['getit'])) {
        $serverPage = explode("?", $_SERVER['REQUEST_URI'], 2); //Get rid of the get parameters from the URL
        if(isset($_SESSION['user'])) {
            if(!$_SESSION['user']->isInstructor) {
                if(isset($_SESSION['class'])) {
                    $_SESSION['class']->sendVote($_REQUEST['getit'] == "true" ? true : false);
                } else {
                    $_SESSION['messages'][] = "You must be in a class to vote!";
                }
            } else {
                $_SESSION['messages'][] = "You cannot vote as an instructor!";
            }
        } else {
            $_SESSION['messages'][] = "You are not logged in";
        }
        header("Location: http://" . $_SERVER['HTTP_HOST'] . $serverPage[0]);
        die;
    }

    switch($_SESSION['state']) {
        case "login": //Default case
            if(isset($_REQUEST['user']) && isset($_REQUEST['password'])) {
                if($_REQUEST['user'] == "" || $_REQUEST['password'] == "") {
                    $_SESSION['messages'][] = "Username or Password cannot be blank";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                //Process Login
                $_SESSION['user'] = new User($_REQUEST['user'], $_REQUEST['password']);
                if($_SESSION['user']->isValidLogin) {
                    if($_SESSION['user']->isInstructor) {
                        $_SESSION['state'] = "createclass";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    } else {
                        $_SESSION['state'] = "joinclass";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    }
                }
            }
            require_once "includes/header.php";
            require_once "view/login.php";
	    break;
        case "profile":
            if(isset($_REQUEST['password'])) {
                if ($_REQUEST['password'] != "") {
                    $_SESSION['user']->updatePassword($_REQUEST['password']);
                }
            }
            if(isset($_REQUEST['user'])) {
                $currUsername = $_SESSION['user']->username;
                if($_REQUEST['user'] != $currUsername) {
                    $_SESSION['messages'][] = "You cannot change your username";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if($_REQUEST['firstName'] == "") {
                    $_SESSION['messages'][] = "First name cannot be blank";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if($_REQUEST['lastname'] != "") {
                    $_SESSION['messages'][] = "Last name canot be blank";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)) {
                    $_SESSION['messages'][] = "Invalid email entered";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if( ($_REQUEST['type'] == "instructor") != $_SESSION['user']->isinstructor) {
                    $_SESSION['messages'][] = "You cannot change your user type";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if($_SESSION['user']->updateUser($_REQUEST['firstName'],
                                                 $_REQUEST['lastName'],
                                                 $_REQUEST['email'])){
                    if($_SESSION['user']->isInstructor) {
                        $_SESSION['state'] = "createclass";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    } else {
                        $_SESSION['state'] = "joinclass";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    }
                } //If this fails, the messages variable is already set
            }
            require_once "includes/header.php";
            require_once "view/profile.php";
            break;
        case "register":
            if (isset($_REQUEST['user'])) {
                if($_REQUEST['user'] == "") {
                    $_SESSION['messages'][] = "Username cannot be blank";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if($_REQUEST['password'] == "") {
                    $_SESSION['messages'][] = "Password cannot be blank";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if($_REQUEST['firstName'] == "") {
                    $_SESSION['messages'][] = "First name cannot be blank";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if($_REQUEST['lastName'] == "") {
                    $_SESSION['messages'][] = "Last name canot be blank";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)) {
                    $_SESSION['messages'][] = "Invalid email entered";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if(User::registerAccount($_REQUEST['user'],
                                         $_REQUEST['password'],
                                         $_REQUEST['firstName'],
                                         $_REQUEST['lastName'],
                                         $_REQUEST['email'],
                                         $_REQUEST['type'] == "instructor")) {
                    if($_SESSION['user']->isInstructor) {
                        $_SESSION['state'] = "createclass";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    } else {
                        $_SESSION['state'] = "joinclass";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    }
                }
            }
            require_once "includes/header.php";
            require_once "view/profile.php";
            break;
        case "createclass":
            if(isset($_REQUEST['which'])) {
                if($_REQUEST['which'] == "create") {
                    if($_REQUEST['class'] == "") {
                        $_SESSION['messages'] = "You must specify a class name";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    }
                    if($_REQUEST['code'] == "") {
                        $_SESSION['messages'] = "You must specify a class code";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    }
                    if(ClassManager::createNewClass($_REQUEST['class'], $_REQUEST['code'])) {
                        if(ClassManager::loadClass($_REQUEST['class'], $_REQUEST['code'])) {
                            $_SESSION['state'] = "icurrentclass";
                        }
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    } else {
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    }
                } elseif ($_REQUEST['which'] == "load") {
                    if($_REQUEST['class'] == "") {
                        $_SESSION['messages'] = "You must specify a class name";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    }
                    if($_REQUEST['code'] == "") {
                        $_SESSION['messages'] = "You must specify a class code";
                        header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                        die;
                    }
                    if (ClassManager::loadClass($_REQUEST['class'], $_REQUEST['code'])) {
                        $_SESSION['state'] = "icurrentclass";
                    }
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
            }                       
            require_once "includes/header.php";
            require_once "view/instructor_createclass.php";
            break;
        case "icurrentclass":
            $_SESSION['class']->updateClass();
            require_once "includes/header.php";
            require_once "view/instructor_currentclass.php";
            break;
        case "scurrentclass":
            require_once "includes/header.php";
            require_once "view/student_currentclass.php";
            break;
        case "joinclass":
            if (isset($_REQUEST['class'])) {
                if($_REQUEST['class'] == "") {
                    $_SESSION['messages'][] = "You must specify a class name";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if($_REQUEST['code'] == "") {
                    $_SESSION['messages'][] = "You must specify a class code";
                    header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    die;
                }
                if(ClassManager::loadClass($_REQUEST['class'], $_REQUEST['code'])) {
                    $_SESSION['state'] = "scurrentclass";
                }
                header("Location: http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                die;
            }
            require_once "includes/header.php";
            require_once "view/student_joinclass.php";
            break;
     }
?>
