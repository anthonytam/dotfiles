		<main>
			<h1><?php echo $_SESSION['state'] == "profile" ? "Profile" : "Registration" ?></h1>
                        <?php
                        MessagePrinting::printMessages();
                        ?>
			<form method="post">
				<fieldset>
					<legend>User Data</legend>
					<p> <label for="user">User</label>
                                            <input type="text" name="user" <?php echo $_SESSION['state'] == "profile" ? 'value="' . $_SESSION['user']->username . '" readonly' : "required"; ?> ></input> </p>
					<p> <label for="password">Password</label>
                                            <input type="password" name="password" <?php echo $_SESSION['state'] == "profile" ? "" : "required"; ?> ></input> </p>
					<p> <label for="firstName">First Name</label>
                                            <input type="text" name="firstName" <?php echo $_SESSION['state'] == "profile" ? 'value="' . $_SESSION['user']->firstname . '" required' : "required"; ?> ></input> </p>
					<p> <label for="lastName">Last Name</label>
                                            <input type="text" name="lastName" <?php echo $_SESSION['state'] == "profile" ? 'value="' . $_SESSION['user']->lastname . '" required' : "required"; ?> ></input> </p>
					<p> <label for="email">email</label>
                                            <input type="text" name="email" pattern="(?!(^[.-].*|[^@]*[.-]@|.*\.{2,}.*)|^.{254}.)([a-zA-Z0-9!#$%&'*+\/=?^_`{|}~.-]+@)(?!-.*|.*-\.)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,15}" <?php echo $_SESSION['state'] == "profile" ? 'value="' . $_SESSION['user']->email . '" required' : "required"; ?> ></input> </p>
					<p> <label for="type">type</label>
					    <input type="radio" name="type" value="instructor" <?php if($_SESSION['state'] == "profile") { echo $_SESSION['user']->isInstructor ? "checked disabled" : "disabled"; } else { echo "required"; } ?>>instructor</input>
					    <input type="radio" name="type" value="student" <?php if($_SESSION['state'] == "profile") { echo !$_SESSION['user']->isInstructor ? "checked disabled" : "disabled"; } ?>>student</input> </p>
					    <input type="submit" />
				</fieldset>
			</form>
		</main>
		<footer>
		</footer>
	</body>
</html>

