		<main>
		    <h1>Class</h1>

                    <?php
                    MessagePrinting::printMessages();
                    ?>
			<form>
				<fieldset>
					<legend> <?php echo $_SESSION['class']->name . " / " . $_SESSION['class']->code; ?> </legend>
					<span style="background-color:green; width:50%;" >i Get It: <?php echo $_SESSION['class']->getIt; ?></span> <br/>
					<span style="background-color:red;  width:30%;"  >i Don't Get It: <?php echo $_SESSION['class']->dontGetIt; ?></span>
				</fieldset>
			</form>
		</main>
		<footer>
		</footer>
	</body>
</html>

