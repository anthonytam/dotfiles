<main>
    <h1>Class</h1>
    <?php
    MessagePrinting::printMessages();
    ?>
    <form method="post">
	<fieldset>
	    <legend>Create Class</legend>
   	    <p> <label for="class">class</label><input type="text" name="class" required></input> </p>
   	    <p> <label for="code">code</label><input type="text" name="code" required></input> </p>
            <input type="hidden" name="which" value="create" />
            <p> <input type="submit" />
	</fieldset>
    </form>
    <form method="post">
        <fieldset>
            <legend>Your Classes</legend>
            <select name="class">
                <?php
                ClassManager::printUserClasses();
                ?>
            </select>
            <p> <label for="code">code</label><input type="text" name="code" required></input> </p>
            <input type="hidden" name="which" value="load" />
            <p> <input type="submit" />
        </fieldset>
    </form>
    <form method="post">
        <fieldset>
            <legend>All Classes</legend>
            <select name="class">
                <?php
                ClassManager::printAllClasses();
                ?>
            </select>
            <p> <label for="code">code</label><input type="text" name="code" required></input> </p>
            <input type="hidden" name="which" value="load" />
            <p> <input type="submit" />
        </fieldset>
    </form>

</main>
<footer>
</footer>
	</body>
</html>

