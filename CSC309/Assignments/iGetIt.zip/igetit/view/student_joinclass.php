		<main>
			<h1>Class</h1>
			<form method="post">
				<fieldset>
					<legend>Current Classes</legend>
					<select name="class">
					    <?php
                                                ClassManager::printAllClasses();
                                            ?>
					</select>
   					<p> <label for="code">code</label><input type="text" name="code"></input> </p>
                                        <p> <input type="submit" />
				</fieldset>
			</form>
		</main>
		<footer>
		</footer>
	</body>
</html>

