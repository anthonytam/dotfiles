		<main>
		    <h1>Class</h1>
                    <?php MessagePrinting::printMessages(); ?>
			<form>
				<fieldset>
					<legend> <?php echo $_SESSION['class']->name . " - " . $_SESSION['class']->owner; ?> </legend>
					<table style="width:100%;">
						<tr>
							<td><a style="background-color:green;" href="?getit=true">i Get It</a></td>
							<td><a style="background-color:red;  " href="?getit=false">i Don't Get It</a></td>
						</tr>
					</table>
				</fieldset>
			</form>
		</main>
		<footer>
		</footer>
	</body>
</html>

