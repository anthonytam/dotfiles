		<main>
			<h1>Login</h1>
                        <?php
                            MessagePrinting::printMessages();
                        ?>
			<form method="post">
				<fieldset>
					<legend>Login</legend>
					<p> <label for="user">User</label>    <input type="text" name="user" required></input> </p>
					<p> <label for="password">Password</label><input type="password" name="password" required></input> </p>
					<p> <input type="submit" />
				</fieldset>
			</form>
                        <p><a href="?request=register">Register!</a></p>
		</main>
		<footer>
		</footer>
	</body>
</html>

