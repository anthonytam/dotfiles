<?php
class Config {
    
    public static function getConfig() {
        $CONFIG = array();

        $CONFIG["database"] = array();
        $CONFIG["database"]["host"] = "mcsdb.utm.utoronto.ca";
        $CONFIG["database"]["user"] = "tamanth2";
        $CONFIG["database"]["pass"] = "17651";
        $CONFIG["database"]["database"] = "tamanth2_309";
        
        return $CONFIG;
    }
}

class MessagePrinting {

    public static function printMessages() {
        foreach($_SESSION['messages'] as $msg) {
            echo "$msg<br>";
         }
	unset($_SESSION['messages']);
    }
}

?>
