<!DOCTYPE html>
<html lang="en">
    <head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css" />
	<title>iGetIt</title>
    </head>
    <body>
	<header><h1>iGetIt</h1></header>
	<nav>
	    <ul>
		<li> <a href="?request=class">Class</a>
		<li> <a href="?request=profile">Profile</a>
		<li> <a href="?request=logout">Logout</a>
	    </ul>
	</nav>
