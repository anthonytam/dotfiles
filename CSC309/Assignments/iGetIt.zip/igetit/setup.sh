#!/bin/bash
read -p "Prompt for sql credentials? (Will open in nano) (y/n) " yesorno
case "$yesorno" in
    y)
        nano ./includes/config.php;;
esac
php ./setup.php
echo "Complete!"
