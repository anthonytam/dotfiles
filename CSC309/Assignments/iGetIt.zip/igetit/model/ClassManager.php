<?php
    class ClassManager {
        public static function createNewClass($className, $classCode) {
            $CONFIG = Config::getConfig();
            $conn = pg_connect("host=" . $CONFIG['database']['host'] .
                                " dbname=" . $CONFIG['database']['database'] .
                                " user=" . $CONFIG['database']['user'] .
                                " password=" . $CONFIG['database']['pass']);
            if($conn) {
                $result = pg_prepare($conn, "classCheck", "SELECT name FROM classlist WHERE name=$1");
                if($result) {
                    if ($result = pg_execute($conn, "classCheck", array($className))) {
                        if($row = pg_fetch_array($result)) {
                            $_SESSION['messages'][] = "A class with that name already exists!";
                            return false;
                        }
                    } else {
                        $_SESSION['messages'][] = "Unable to querry the database";
                        return false;
                    }
                } else {
                    $_SESSION['messages'][] = "Unable to create the prepared statement";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Unable to connect to the database";
                return false;
            }

            $result = pg_prepare($conn, "classCreate", "INSERT INTO classlist (name, code, owner) VALUES ($1, $2, $3)");
            if($result) {
                $result = pg_execute($conn, "classCreate", array($className, $classCode, $_SESSION['user']->username));
                if($result) {
                    $_SESSION['messages'] = "The class has been created!";
                    $_SESSION['user']->inClass = $className;
                    return true;
                } else {
                    $_SESSION['messages'][] = "Unable to query the database";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Unable to create the prepared statement";
                return false;
            }                   
        }

        public static function loadClass($class, $code) {
            $CONFIG = Config::getConfig();
            $conn = pg_connect("host=" . $CONFIG['database']['host'] .
                               " dbname=" . $CONFIG['database']['database'] .
                               " user=" . $CONFIG['database']['user'] .
                               " password=" . $CONFIG['database']['pass']);
            if($conn) {
                $result = pg_prepare($conn, "classValidate", "SELECT code, owner, notes FROM classlist WHERE name=$1");
                if($result) {
                    if ($result = pg_execute($conn, "classValidate", array($class))) {
                        if($row = pg_fetch_array($result)) {
                            if($row['code'] != $code) {
                                $_SESSION['messages'][] = "Invalid code was given";
                                return false;
                            } else {
                                $_SESSION['class'] = new ClassInfo($class, $code, $row['owner'], $row['notes']);
                                return true;
                            }
                        } else {
                            $_SESSION['messages'][] = "No class with that name was found";
                            return false;
                        }
                    } else {
                        $_SESSION['messages'][] = "Unable to querry the database";
                        return false;
                    }
                } else {
                    $_SESSION['messages'][] = "Unable to create the prepared statement";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Unable to connect to the database";
                return false;
            }
        }

        public static function printAllClasses() {
            $CONFIG = Config::getConfig();
            $conn = pg_connect("host=" . $CONFIG['database']['host'] .
                               " dbname=" . $CONFIG['database']['database'] .
                               " user=" . $CONFIG['database']['user'] .
                               " password=" . $CONFIG['database']['pass']);
            if($conn) {
                $result = pg_prepare($conn, "getAllClasses", "SELECT name FROM classlist");
                if($result) {
                    if ($result = pg_execute($conn, "getAllClasses", array())) {
                        while ($row = pg_fetch_array($result)) {
                            echo '<option value="' . $row['name'] . '">' . $row['name'] . '</option>';
                        }
                    } else {
                        $_SESSION['messages'][] = "Unable to querry the database";
                        return false;
                    }
                } else {
                    $_SESSION['messages'][] = "Unable to create the prepared statement";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Cannot connect to the database";
                return false;
            }
        }

        public static function printUserClasses() {
            $CONFIG = Config::getConfig();
            $conn = pg_connect("host=" . $CONFIG['database']['host'] .
                               " dbname=" . $CONFIG['database']['database'] .
                               " user=" . $CONFIG['database']['user'] .
                               " password=" . $CONFIG['database']['pass']);
            if($conn) {
                $result = pg_prepare($conn, "getUserClasses", "SELECT name FROM classlist WHERE owner=$1");
                if($result) {
                    if ($result = pg_execute($conn, "getUserClasses", array($_SESSION['user']->username))) {
                        while ($row = pg_fetch_array($result)) {
                            echo '<option value="' . $row['name'] . '">' . $row['name'] . '</option>';
                        }
                    } else {
                        $_SESSION['messages'][] = "Unable to querry the database";
                        return false;
                    }
                } else {
                    $_SESSION['messages'][] = "Unable to create the prepared statement";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Cannot connect to the database";
                return false;
            }
        }
    }
?>
