<?php

class User {
    public $isValidLogin;
    public $username;
    public $firstName;
    public $lastName;
    public $email;
    public $isInstructor;
    public $inClass;
    
    // Salt the password before entering into the database
    // Documentation on previding a secure has can be found at the below link
    // Uses random values which are secure for use in cryptography.
    // Also used examples here in this function.
    // http://php.net/manual/en/function.password-hash.php
    private static function saltPassword($password) {
        $limit = 0.7;
        $cost = 8;
        do {
            $cost++;
            $startingTime = microtime(true);
            password_hash($password, PASSWORD_BCRYPT, array("cost" => $cost));
            $endingTime = microtime(true);
        } while (($endingTime - $startingTime) < $limit);
        return password_hash($password, PASSWORD_BCRYPT, array("cost" => $cost));
    }
    
    public static function registerAccount($username, $password, $firstName, $lastName, $email, $isInstructor) {
        $CONFIG = Config::getConfig();
        $conn = pg_connect("host=" . $CONFIG['database']['host'] .
                           " dbname=" . $CONFIG['database']['database'] .
                           " user=" . $CONFIG['database']['user'] .
                           " password=" . $CONFIG['database']['pass']);
        $result = pg_prepare($conn, "usernameCheck", "SELECT username FROM appuser WHERE username=$1");
        if ($result) {
            $result = pg_execute($conn, "usernameCheck", array($username));
            if($result) {
                if($row = pg_fetch_array($result)) {
                    $_SESSION['messages'][] = "An account with that username already exists";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Unable to query the database";
                return false;
            }
        } else {
            $_SESSION['messages'][] = "Unable to create the prepared statement";
            return false;
        }
        $result = pg_prepare($conn, "userCreate", "INSERT INTO appuser (username, password, firstName, lastName, email, isinstructor) VALUES ($1, $2, $3, $4, $5, $6)");
	if ($result) {
            $saltedPassword = self::saltPassword($password);
            $result = pg_execute($conn, "userCreate", array($username, $saltedPassword, $firstName, $lastName, $email, $isInstructor ? 1 : 0));
            if ($result) {
                $_SESSION['messages'][] = "Your account was created sucessfully!";
                $_SESSION['user'] = new User($username, $password);
                return true;
            } else {
                $_SESSION['messages'][] = "Unable to query the database";
                return false;
            }
        } else {
            $_SESSION['messages'][] = "Unable to create the prepared statement";
            return false;
        }
    }
    
    public function __construct($username, $password) {
        $CONFIG = Config::getConfig();
        $saltedPassword = "";
        $conn = pg_connect("host=" . $CONFIG['database']['host'] .
                           " dbname=" . $CONFIG['database']['database'] .
                           " user=" . $CONFIG['database']['user'] .
                           " password=" . $CONFIG['database']['pass']);
        $result = pg_prepare($conn, "getHash", "SELECT password FROM appuser WHERE username=$1");
        if ($result) {
            $result = pg_execute($conn, "getHash", array($password));
            if ($result) {
                if ($row = pg_fetch_array($result)) {
                    $saltedPassword = $row['password'];
                } else {
                    $_SESSION['messages'][] = "No account with the given username or password found";
                    $isValidLogin = false;
                }
            } else {
                $_SESSION['messages'][] = "Unable to query the database";
                $isValidLogin = false;
            }
        } else {
            $_SESSION['messages'][] = "Unable to create the prepared statement";
            $isValidLogin = false;
        }
        if (password_verify($password, $saltedPassword)) {
            $result = pg_prepare($conn, "userLogin", "SELECT firstname, lastname, email, isinstructor FROM appuser WHERE username=$1 LIMIT 1");
	    if ($result) {
                $result = pg_execute($conn, "userLogin", array($username));
                if ($result) {
                    if ($row = pg_fetch_array($result)) {
                        $this->username = $username;
                        $this->firstname = $row['firstname'];
                        $this->lastname = $row['lastname'];
                        $this->email = $row['email'];
                        $this->isInstructor = (int)$row['isinstructor'] == 1;
                        $this->isValidLogin = true;
                    }
                } else {
                    $_SESSION['messages'][] = "Failed to query the database";
                    $isValidLogin = false;
                }
            } else {
                $_SESSION['messages'][] = "Failed to create prepared statement";
                $isValidLogin = false;
            }
        } else {
            $_SESSION['messages'][] = "No account with the given username or password found";
            $isValidLogin = false;
        }
    }

     public function updateUser($newFirstName, $newLastName, $newEmail) {
         $CONFIG = Config::getConfig();
         $conn = pg_connect("host=" . $CONFIG['database']['host'] . " dbname=" . $CONFIG['database']['database'] . " user=" . $CONFIG['database']['user'] . " password=" . $CONFIG['database']['pass']);
         $result = pg_prepare($conn, "accountUpdate", "UPDATE appuser SET firstname=$1, lastname=$2, email=$3 WHERE username=$4");
         if ($result) {
             $result = pg_execute($conn, "accountUpdate", array($newFirstName, $newLastName, $newEmail, $this->username));
             if($result) {
                 $this->firstname = $newFirstName;
                 $this->lastname = $newLastName;
                 $this->email = $newEmail;
                 $_SESSION['messages'][] = "Account updated successfully!";
                 return true;
             } else {
                 $_SESSION['messages'][] = "Unable to update the database";
                 return false;
             }
         } else {
             $_SESSION['messages'][] = "Unable to create prepared statement";
             return false;
         }
    }

    public function updatePassword($password) {
        $saltedPassword = hash("sha256", self::SALT . $password);
        $CONFIG = Config::getConfig();
        $conn = pg_connect("host=" . $CONFIG['database']['host'] . " dbname=" . $CONFIG['database']['database'] . " user=" . $CONFIG['database']['user'] . " password=" . $CONFIG['database']['pass']);
        $result = pg_prepare($conn, "passwordUpdate", "UPDATE appuser SET password=$1 WHERE username=$2");
        if ($result) {
            $result = pg_execute($conn, "passwordUpdate", array($saltedPassword, $this->username));
            if($result) {
                $_SESSION['messages'][] = "Account password updated successfully!";
            } else {
                $_SESSION['messages'][] = "Unable to update account password";
            }
        } else {
            $_SESSION['messages'][] = "Unable to create prepared password statement";
        }       
    }
}
?>
