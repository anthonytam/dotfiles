<?php
class ClassInfo {
    public $name;
    public $code;
    public $owner;
    public $notes;
    public $getIt;
    public $dontGetIt;

    public function __construct($name, $code, $owner, $notes) {
        $this->name = $name;
        $this->code = $code;
        $this->owner = $owner;
        $this->notes = $notes;
        $this->getIt = 0;
        $this->dontGetIt = 0;
        $this->updateClass();
    }

    public function sendVote($vote) {
        $CONFIG = Config::getConfig();
        $conn = pg_connect("host=" . $CONFIG['database']['host'] .
                           " dbname=" . $CONFIG['database']['database'] .
                           " user=" . $CONFIG['database']['user'] .
                           " password=" . $CONFIG['database']['pass']);
        if($conn) {
            // Time difference in SQL from here:
            // http://stackoverflow.com/questions/14020919/find-difference-between-timestamps-in-seconds-in-postgresql
            $result = pg_prepare($conn, "checkVote", "SELECT EXTRACT (EPOCH FROM (max(votetime) - NOW())) AS votediff FROM classvotes WHERE username=$1 AND classname=$2");
            if($result) {
                $result = pg_execute($conn, "checkVote", array($_SESSION['user']->name, $this->name));
                if ($result) {
                    if(pg_num_rows($result) == 1) {
                        $row = pg_fetch_array($result);
                        if(false /*abs((int)$row['votediff']) < 180 && abs((int)$row['votediff']) != 0*/) { //3 minute constraint
                            $_SESSION['messages'][] = "You must wait 3 minutes between votes!";
                            return false;
                        }
                    } else {
                        $_SESSION['messages'][] = "Unable to querry the database";
                        return false;
                    }
                } else {
                    $_SESSION['messages'][] = "Unable to query the database";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Unable to create the prepared statement";
                return false;
            }
            
            $result = pg_prepare($conn, "addVote", "INSERT INTO classvotes (classname, username, vote, votetime) VALUES ($1, $2, $3, NOW())");
            if($result) {
                $result = pg_execute($conn, "addVote", array($this->name, $_SESSION['user']->username, $vote ? 1 : 0));
                if ($result) {
                    $this->updateClass();                
                    $_SESSION['messages'][] = "Vote accepted";
                } else {
                    $_SESSION['messages'][] = "Unable to querry the database";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Unable to create the prepared statement";
                return false;
            }
        } else {
            $_SESSION['messages'][] = "Unable to connect to the database";
        }
    }
    
    public function updateClass() {
        $CONFIG = Config::getConfig();
        $conn = pg_connect("host=" . $CONFIG['database']['host'] .
                           " dbname=" . $CONFIG['database']['database'] .
                           " user=" . $CONFIG['database']['user'] .
                           " password=" . $CONFIG['database']['pass']);
        if($conn) {
            $result = pg_prepare($conn, "updateClass", "SELECT vote FROM classvotes WHERE classname=$1");
            if($result) {
                if ($result = pg_execute($conn, "updateClass", array($this->name))) {
                    $this->getIt = 0;
                    $this->dontGetIt = 0;
                    while ($row = pg_fetch_array($result)) {
                        if ($row['vote'] == 1)
                            $this->getIt++;
                        else
                            $this->dontGetIt++;
                    }
                    return true;
                } else {
                    $_SESSION['messages'][] = "Unable to querry the database";
                    return false;
                }
            } else {
                $_SESSION['messages'][] = "Unable to create the prepared statement";
                return false;
            }
        } else {
            $_SESSION['messages'][] = "Unable to connect to the database";
            return false;
        }
    }
}

?>
