<?php
require_once "includes/config.php";
$CONFIG=Config::getConfig();
$conn = pg_connect("host=" . $CONFIG['database']['host'] .
                   " dbname=" . $CONFIG['database']['database'] .
                   " user=" . $CONFIG['database']['user'] .
                   " password=" . $CONFIG['database']['pass']);
pg_prepare($conn, "addtables", "CREATE TABLE IF NOT EXISTS appuser (
username varchar(30) primary key,
password varchar(64),
firstname varchar(20),
lastname varchar(20),
email  varchar(20),
isinstructor int
);");
pg_execute($conn, "addtables", array());


pg_prepare($conn, "addothertable", "CREATE TABLE IF NOT EXISTS classlist (
name varchar(20) primary key,
code varchar(20),
notes varchar(20),
owner varchar(20)
);");
pg_execute($conn, "addothertable", array());

pg_prepare($conn, "addotable", "CREATE TABLE IF NOT EXISTS classvotes (
id serial primary key,
classname varchar(20),
username varchar(30),
vote int,
votetime timestamp
);");
pg_execute($conn, "addotable", array());

?>
